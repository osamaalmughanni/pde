<?php
if(isset($_POST['comment'])) {
	$fp = fopen($_POST["path"], 'a');
	fwrite($fp, date("Y-m-d H:i")." • ".$_POST['comment']."\n");
	fclose($fp);
}
?>