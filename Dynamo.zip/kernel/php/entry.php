<?php
if (!file_exists($root.'/dyn/'.$tool['id'])) {
    mkdir($root.'/dyn/'.$tool['id'], 0777, true);
}
?>

<?php $git_input = 'osamaalmughanni/dynre.github.io'; ?>
<?php $git = 'https://raw.githubusercontent.com/'.$git_input.'/main/'; ?>

<!-- Start -->

<article class="masonry-brick entry format-standard animate-this">
	<main class="entry-post">
		
		<div class="entry-script">
		
		<?php if ($tool["name"]): ?>
			<div class="entry-title">
				<div class="entry-play" id="<?php echo $tool["id"]; ?>" url="<?php echo $git. implode(",".$git, $tool['dyn']); ?>" onclick="scriptRun('<?php echo $tool["id"]; ?>')"><img src="<?php echo 'kernel/img/play.svg'; ?>"></div>
				
				<div class="entry-name">
				<?php echo $tool["name"]; ?>
				</div>
				
			<div class="entry-pin">
				<form class="pin" id="pin <?php echo $tool['id']; ?>">
				<input type="hidden" id="pin" name="pin" value="<?php echo $tool['id']; ?>"/>
				
				<label id="pinicon<?php echo $tool['id']; ?>" <?php if ($_COOKIE[$tool['id']]):?> class="pinned" <?php else: ?> class="not-pinned" <?php endif ?>>
				
				<input name="pin" type="submit" name="submit" value="" />
				</label>
				</form>
			</div>

			</div>
		<?php endif ?>
		
		<?php if ($tool["description"]): ?>
		<div class="entry-header">
			<div class="entry-description">
				<?php echo $tool["description"] ?>
			</div>
		</div>
		<?php endif ?>
		
		</div>
		
		<div class="entry-meta">
		
		<div class="tooltip" id="toolid" onclick="copyToClipboard(<?php echo $tool['id']; ?>)">
		  <div class="tooltip-img"><img src="<?php echo 'kernel/img/info.svg'; ?>"></div>  
		  <span class="tooltiptext"><?php echo $tool["id"]; ?></span>
		</div>
		
		<div class="tooltip">
		  <div class="tooltip-img"><a target="_blank" href="<?php echo $tool["tutorial"]; ?>" ><img src="<?php echo 'kernel/img/tutorial.svg'; ?>"></a></div>  
		  <span class="tooltiptext"><?php echo $tool["tutorial"]; ?></span>
		</div>

		<?php if ($tool["modified"]): ?>
		<div class="tooltip">
		  <div class="tooltip-img"><img src="<?php echo 'kernel/img/lastupdate.svg'; ?>"></div>  
		  <span class="tooltiptext"><?php echo $tool["modified"]; ?></span>
		</div>
		<?php endif ?>
		
		<?php if ($tool["author"]): ?>
		<div class="tooltip">
		  <div class="tooltip-img"><img src="<?php echo 'kernel/img/creatorname.svg'; ?>"></div>  
		  <span class="tooltiptext"><?php echo $tool["author"]; ?></span>
		</div>
		<?php endif ?>

		<?php if ($tool["dependencies"]): ?>
		<div class="tooltip">
		  <div class="tooltip-img"><img src="<?php echo 'kernel/img/dependencies.svg'; ?>"></div>  
		  <span class="tooltiptext"><?php echo implode("<br>", $tool["dependencies"]); ?></span>
		</div>
		<?php endif ?>

		<?php if ($tool["projects"]): ?>
		<div class="tooltip">
		  <div class="tooltip-img"><img src="<?php echo 'kernel/img/projects.svg'; ?>"></div>  
		  <span class="tooltiptext"><?php echo implode("<br>", $tool["projects"]); ?></span>
		</div>
		<?php endif ?>

		<?php if ($tool["clicks"]): ?>
		<div class="tooltip">
		  <div class="tooltip-img"><img src="<?php echo 'kernel/img/numberofclicks.svg'; ?>"></div>
		  <span class="tooltiptext"><?php echo $tool["clicks"]; ?></span>
		</div>
		<?php endif ?>

		<?php
		$file=$root."/dyn/".$tool["id"]."/ratings.txt";
		$likes=file_get_contents($file);
		$likes=explode(PHP_EOL, $likes);
		//print_r($likes);
		$a = array_filter($likes);
		$average = array_sum($a)/count($a);
		?>

		<div class="my-rating-7" id="<?php echo $tool['id']; ?>" data-rating="<?php echo $average; ?>"></div>

		<?php // include('kernel/php/comments.php'); ?>
		
		</div>
		
	</main>	
</article>


<!-- End -->