<div class="comments">
<div class="collapsible"><div class="tooltip-img comment"><img src="<?php echo 'kernel/img/comments.svg'; ?>"></div></div>
<div class="content">

<form class="comments" method="post" autocomplete="off">
<div class="textarea-container">
<input name="comment" class="comment" placeholder="Add a comment.." maxlength ="100" spellcheck="false" autocomplete="false" >
<input type="hidden" name="path" value="<?php echo 'dyn/'.$tool['id'].'/comments.txt'; ?>" />

<button class="submit" type="submit" name="submit">Send</button>
</div>
</form>

	<?php
	$commentsFile = 'dyn/'.$tool["id"].'/comments.txt';
	if (file_exists($commentsFile)) {
		$file = array_reverse(file($commentsFile, FILE_IGNORE_NEW_LINES));
	} else {
		$file = "";
	}
	foreach($file as $key=>$item){		
		$file[$key] = explode(" • ", $item);
	}
	?>

	<div class="comments-box">
	<?php foreach ($file as $key=>$item):?>
	<div class="comment">
		<div class="comment-line">
		<span class="comment-text"><?php echo " • ".$item[1]; ?></span>
		<span class="comment-date"><?php echo time_elapsed_string($item[0]); ?></span>
		</div>
	</div>
	<?php endforeach ?>
	</div>
	
</div>
</div>