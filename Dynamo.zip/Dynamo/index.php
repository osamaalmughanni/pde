<!DOCTYPE html>
<?php error_reporting(0); ?>
<?php include('kernel/php/head.php'); ?>
<?php include('kernel/php/post.php'); ?>
<?php include('kernel/php/functions.php'); ?>

<?php
$git = $_COOKIE['git'];

if(!$git)
	$git = "osamaalmughanni/porr";

$json = json_decode(file_get_contents('https://raw.githubusercontent.com/'.$git.'/main/scripts.json'), true);
$allcategories = $json["categories"];
$tools = $json["tools"];

$categoryPage = trim($_SERVER['REQUEST_URI'], '/');
foreach ($allcategories as $value) {
		if($value["slug"] == $categoryPage) {
			$categoryKey = $value["id"];
			$categoryName = $value["name"];
			$categoryDescription = $value["description"];
			$categoryEmoji = $value["emoji"];
			$categorySlug = $value["slug"];
		}
}

foreach ($tools as $value) {
		if($value["id"] == $categoryPage) {
			$toolKey = $value["id"];
		}
}

?>

<body>
	
	<!-- site content
	================================================== -->
	<?php
	if ($categoryPage == "pin" && $tools) {
			include('kernel/php/sidebar.php');
			include('kernel/php/pin.php');
	} elseif ($categoryPage && $tools) {
			include('kernel/php/sidebar.php');
			include('kernel/php/category.php');
	} elseif ($tools) {
			include('kernel/php/sidebar.php');
			include('kernel/php/home.php');
	} else {
			include('kernel/php/404.php');
	}
	?>	
    <!-- Java Script
    ================================================== -->
	<script src="/kernel/js/jquery.min.js"></script>
	<script src="/kernel/js/jquery.star-rating-svg.js"></script>
	<script src="/kernel/js/ajax.js"></script>

	<script>
	function copyToClipboard(text) {
		var dummy = document.createElement("textarea");
		// to avoid breaking orgain page when copying more words
		// cant copy when adding below this code
		// dummy.style.display = 'none'
		document.body.appendChild(dummy);
		//Be careful if you use texarea. setAttribute('value', value), which works with "input" does not work with "textarea". – Eduard
		dummy.value = text;
		dummy.select();
		document.execCommand("copy");
		document.body.removeChild(dummy);
	}
	</script>

	<script>
	var coll = document.getElementsByClassName("collapsible");
	var i;

	for (i = 0; i < coll.length; i++) {
	  coll[i].addEventListener("click", function() {
		this.classList.toggle("active");
		var content = this.nextElementSibling;
		if (content.style.display === "block") {
		  content.style.display = "none";
		} else {
		  content.style.display = "block";
		}
	  });
	}
	</script>

	<script>
	$(".my-rating-7").starRating({
	totalStars: 5,
	  starSize: 14,
	  useGradient: false,
	  callback: function(currentRating, $el){
		//alert('rated ' + currentRating);
		//alert($($el).attr('id'));

		var id = $($el).attr('id');
		var rating = currentRating;
		var userdata = {'id':id,'rating':rating};
		
		$.ajax({
			url: '/kernel/php/ajax/like.php',
			dataType: 'text',
			type: 'post',
			contentType: 'application/x-www-form-urlencoded',
			data: userdata,
			success: function( data, textStatus, jQxhr ){
				window.location.reload();
			},
			error: function( jqXhr, textStatus, errorThrown ){
				console.log( errorThrown );
			}
		});

	  }
	});
	</script>

</body>