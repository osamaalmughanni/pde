(function($){
	function processFormPin( e ){
		$.ajax({
			url: 'kernel/php/ajax/pin.php',
			dataType: 'text',
			type: 'post',
			contentType: 'application/x-www-form-urlencoded',
			data: $(this).serialize(),
			success: function( data, textStatus, jQxhr ){
				window.location.reload();
			},
			error: function( jqXhr, textStatus, errorThrown ){
				console.log( errorThrown );
			}
		});

		e.preventDefault();
	}

	$('.pin').submit( processFormPin );
})(jQuery);