<header class="s-sidebar">

<div class="s-menu-desktop">
<?php $active = ($categoryPage == "")? 'active': ''; ?>
<div class="s-menu-desktop-item"><a class="s-menu-link <?php echo $active; ?>" href="/"><?php echo $json["emoji"]; ?></a></div>

<?php foreach ($allcategories as $category): ?>
<?php $active = ($category["slug"] == $categoryPage)? 'active': ''; ?>
<div class="s-menu-desktop-item"><a class="s-menu-link <?php echo $active; ?>" href="<?php echo $category["slug"]; ?>"><?php echo $category["emoji"]; ?></a></div>
<?php endforeach ?>
</div>

</header>