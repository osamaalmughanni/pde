<div class="s-footer">
© <?php echo date("Y");?>
</div>