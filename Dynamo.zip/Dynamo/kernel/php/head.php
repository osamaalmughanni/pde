<!--- basic page needs
================================================== -->
<meta charset="utf-8">
<meta name="author" content="">
<meta name="generator" content="dynre*">
<meta name="keywords" content="revit, automation, tools, plugin">
<meta name="google" content="notranslate"/>
<meta name="robots" content="noindex" />
<html lang="en" class="notranslate" translate="no"/>

<!-- mobile specific metas
================================================== -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" href="kernel/img/favicon.svg" sizes="any" type="image/svg+xml">
<?php echo "<link rel='stylesheet' href='kernel/css/main.css?".time()."'>"; ?>
<?php echo "<link rel='stylesheet' href='kernel/css/typography.css?".time()."'>"; ?>

<?php $root = (!empty($_SERVER['HTTPS']) ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . '/'; ?>

<script>
function scriptRun(guid) {
	const myAnchor = document.getElementById(guid) 
	let text = myAnchor.getAttribute("url");
	
	// REVIT 2023
	//CefSharp.PostMessage(text);
	
	// REVIT 2022
	callbackObj.showMessage(text);
}
</script>

<script>
function searchFunction() {
    var input, filter, ul, li, a, i, txtValue;
    input = document.getElementById("searchInput");
    filter = input.value.toUpperCase();
    ul = document.getElementById("masonry");
    li = ul.getElementsByTagName("main");
    for (i = 0; i < li.length; i++) {
        a = li[i];
        txtValue = a.textContent || a.innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
            a.style.display = "";
        } else {
            a.style.display = "none";
        }
    }
}
</script>