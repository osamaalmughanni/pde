<div class="s-content">
<?php include('kernel/php/connect.php'); ?>
<div class="page-header">	
	<div class="page-title">	
		<?php echo $categoryEmoji." ".$categoryName; ?>
	</div>

	<div class="page-content">	
		<p><?php echo $categoryDescription ?></p>
	</div>
</div>

<div class="search">
<input type="text" id="searchInput" oninput="searchFunction()" placeholder="Suche ein Tool.." title="Type in a name" spellcheck="false">
</div>

<div class="masonry-wrap">
    <div class="masonry" id="masonry">
	<div class="grid-sizer"></div>

	<!-- Articles -->
	<?php foreach ($tools as $tool):?>
			
			<?php if ($_COOKIE[$tool['id']] == $tool['id']):?>
			
			<?php include('kernel/php/entry.php'); ?>
			
			<?php endif ?>
	
		<?php endforeach ?>
    </div> <!-- end masonry -->
</div> <!-- end masonry-wrap -->


	<?php if (!$_COOKIE):?>
		<div class="message">
		💡 Du hast noch keine Tools gepinnt!
		</div>
	<?php endif ?>

<?php include('kernel/php/footer.php'); ?>

</div> <!-- end s-content -->