<?php

if($_POST['pin']) {
	$cookieValue = $_POST["pin"];
	if (isset($_COOKIE[$cookieValue])) {
		setcookie($cookieValue, "", time()+10*365*24*60*60, '/');
	} else {
		setcookie($cookieValue, $cookieValue, time()+10*365*24*60*60, '/');
	}
}