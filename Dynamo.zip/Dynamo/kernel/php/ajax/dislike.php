<?php

$file = $_POST["path"];
$counter = 1;   
if (file_exists($file)) {
	$counter += file_get_contents($file);
}
file_put_contents($file, $counter);

?>