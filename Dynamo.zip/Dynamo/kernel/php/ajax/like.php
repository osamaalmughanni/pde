<?php

$file = "../../../dyn/".$_POST["id"]."/ratings.txt";
$rating = $_POST["rating"];
file_put_contents($file, $rating.PHP_EOL, FILE_APPEND);

?>