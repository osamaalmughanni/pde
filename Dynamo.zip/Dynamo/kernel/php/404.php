<div class="s-content">
<?php include('kernel/php/connect.php'); ?>

<div class="s-404">
<div class="page-header">	
	<div class="page-title">	
		🙄 Whoops!
	</div>

	<div class="page-content">	
		<p>
		The repository you entered do not contain any dynamo scripts or does not follow our JSON scheme.
		</p>
	</div>
</div>

</div>

</div>